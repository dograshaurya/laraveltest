<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Stripe\Stripe;
use Stripe\Charge;

class ProductController extends Controller
{
    // For simplicity, you can assume there are two products: B2C and B2B
    public function purchase(Request $request)
    {
    // Handle product purchase logic here

        $productType = $request->input('product_type');

        Stripe::setApiKey(config('services.stripe.secret'));

        try {
            // Process payment with Stripe, you should have a product-specific amount and description
            $charge = Charge::create([
                'amount' => $amount, // Amount in cents
                'currency' => 'usd',
                'source' => $request->stripeToken,
                'description' => 'Product Purchase: ' . $productType,
            ]);

            // Handle successful payment and role assignment
            if ($productType === 'B2C') {
                auth()->user()->assignRole('B2C Customer');
            } elseif ($productType === 'B2B') {
                auth()->user()->assignRole('B2B Customer');
            }

            // Redirect to a success page
            return redirect()->route('dashboard')->with('success', 'Product purchased successfully.');
        } catch (\Exception $e) {
            // Handle payment failure
            return back()->with('error', 'Payment failed. Please try again.');
        }
    }
}
