 <!-- You can use your own layout if available -->

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Purchase a Product')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('purchase')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <label for="product_type">Select Product:</label>
                            <select name="product_type" id="product_type" class="form-control" required>
                                <option value="B2C">B2C Product</option>
                                <option value="B2B">B2B Product</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="card-element">Credit Card Details:</label>
                            <div id="card-element">
                                <!-- A Stripe Element will be inserted here. -->
                            </div>

                            <!-- Used to display form errors. -->
                            <div id="card-errors" role="alert"></div>
                        </div>

                        <button type="submit" class="btn btn-primary">
                            <?php echo e(__('Purchase')); ?>

                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<!-- Include Stripe.js library -->
<script src="https://js.stripe.com/v3/"></script>

<!-- JavaScript to handle Stripe payment -->
<script>
    // Create a Stripe client
    var stripe = Stripe('<?php echo e(config('services.stripe.key')); ?>');

    // Create an instance of Elements
    var elements = stripe.elements();

    // Create a card Element
    var card = elements.create('card');

    // Add the card Element to the DOM
    card.mount('#card-element');

    // Handle real-time validation errors from the card Element
    card.addEventListener('change', function(event) {
        var displayError = document.getElementById('card-errors');
        if (event.error) {
            displayError.textContent = event.error.message;
        } else {
            displayError.textContent = '';
        }
    });

    // Handle form submission
    var form = document.getElementById('payment-form');
    form.addEventListener('submit', function(event) {
        event.preventDefault();

        // Disable the submit button to prevent multiple submissions
        document.getElementById('purchase-button').disabled = true;

        // Create a payment method with the card Element
        stripe.createPaymentMethod({
            type: 'card',
            card: card,
        }).then(function(result) {
            if (result.error) {
                // Show error to your customer (e.g., insufficient funds, card declined)
                var errorElement = document.getElementById('card-errors');
                errorElement.textContent = result.error.message;

                // Enable the submit button
                document.getElementById('purchase-button').disabled = false;
            } else {
                // Tokenize the payment method ID and send it to your server
                var token = result.paymentMethod.id;

                // Append the token to the form data
                var hiddenInput = document.createElement('input');
                hiddenInput.setAttribute('type', 'hidden');
                hiddenInput.setAttribute('name', 'stripeToken');
                hiddenInput.setAttribute('value', token);
                form.appendChild(hiddenInput);

                // Submit the form
                form.submit();
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\laravel-test\resources\views/purchase.blade.php ENDPATH**/ ?>